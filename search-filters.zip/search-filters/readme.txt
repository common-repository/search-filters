=== Search filters ===
Contributors: Siarhei Zarouski
Donate link: 
Tags: search, filter
Requires at least: 2.8
Tested up to: 2.8.5
Stable tag: 1.0

Filtering your search results by category, tags, or date.

== Description ==

Filtering your search results by category, tags, or date.

== Installation ==

1. Upload folder `search-filters` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Place `<?php if(function_exists('search_filters')) search_filters(); ?>` in your templates. Filters switcher will appear after search.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.jpg.
That is how it looks

== Frequently Asked Questions ==
no questions yet

== Changelog ==
this is the first version of plugin