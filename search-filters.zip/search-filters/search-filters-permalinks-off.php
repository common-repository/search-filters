<?php
/*
Plugin Name: Search filters
Plugin URI: http://
Description: Filtering your search results by category, tags, or date.
Version: 1.0
Author: Siarhei Zarouski
Author URI: http://

============================================================================================================
This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

For full license details see license.txt
============================================================================================================ */

function search_filters(){
	if(is_search()) { ?>
		<h2>Filter search results</h2>
		<h4>-by category</h4>
		<ul>
			<?php 
			$searching = get_search_query(); //get search query
			
			$a=$b=$i=0; //set counters
			
			$filter_categories_array = array(); //set array for categories
			$filter_tags_array = array(); //for tages
			$filter_date_array = array(); //for dates
			
			while (have_posts()) : the_post();
				foreach((get_the_category()) as $category) { //get category values
    			$categores = '<li><a href="'.get_option('home').'?s='.$searching.'&cat='.$category->cat_ID.'">'.$category->cat_name.'</a></li>'; //set and save link to category with search filter
    			$filter_categories_array[$i] = $categores; //saving link from current post to array
    			$i++;
				}
				
				$all_the_tags = get_the_tags(); //save defoult array to var
				if ($all_the_tags) {
				foreach($all_the_tags as $this_tag) { //get tags values
    			$this_tag = '<li><a href="'.get_option('home').'/?s='.$searching.'&tag='.$this_tag->slug.'">'.$this_tag->name.'</a></li>'; //set and save link to tag with search filter
    			$filter_tags_array[$a] = $this_tag; //saving link from current post to array
    			$a++;
				}
				}
				
				$all_date = get_the_time('j.m.Y', '', '', FALSE);//sets how dates will appear
				$date_link = get_the_time('Ymd', '', '', FALSE);//sets links path
    			if (isset($all_date)) {//remove blank links
				$date = '<li><a href="'.get_option('home').'/'.'/?s='.$searching.'&m='.$date_link.'">'.$all_date.'</a></li>'; //set and save link to date with search filter
    			$filter_date_array[$b] = $date; //saving link from current post to array
    			$b++;
    			}
			endwhile;
			
			//now all category links are saved to arrays
			$clear_filter_categories_array = array_unique($filter_categories_array); //unset repeating links
			$clear_filter_tags_array = array_unique($filter_tags_array); //unset repeating links
			$clear_filter_date_array = array_unique($filter_date_array); //unset repeating links
			
			for($i=0;$i<count($filter_categories_array);$i++) {
				echo $clear_filter_categories_array[$i];//display links
			}
			
			
			if ($filter_categories_array == null ) {
				echo "<li>No categories</li>";
			}
			?>
		</ul>
		<h4>-by tag</h4>
		<ul>
			<?php
			for($i=0;$i<count($filter_tags_array);$i++) {
				echo $clear_filter_tags_array[$i];//display links
			}
			if ($filter_tags_array == null ) {
				echo "<li>No tags</li>";
			}
			?>
		</ul>
		<h4>-by date</h4>
		<ul>
			<?php
			for($i=0;$i<count($filter_date_array);$i++) {
				echo $clear_filter_date_array[$i];//display links
			}
			if ($filter_date_array == null ) {
				echo "<li>No dates</li>";
			}
			?>
		</ul>
		<?php } 
	}
?>